# Contributing to Byte Fortress Learn — Binary Exploitation Fundamentals

Thanks for wanting to improve this curriculum. To keep the project
usable, safe to host publicly, and consistent, please follow the
pattern below.

## What we accept

- **New modules** following the existing structure: `README.md`
  (objectives + external resource link) + `template.c` (bare,
  non-vulnerable skeleton) + `validate.sh` (structural/checksec
  validation only, no exploit logic).
- **Improvements to tooling** (`tools/`): setup scripts, checksec
  wrappers, build helpers, environment fixes.
- **Documentation improvements**: clearer explanations of concepts,
  better VM setup instructions, corrections to external resource
  links, translations (English/Spanish both welcome).
- **New external resource references**: if you know of a good,
  well-maintained open-source teaching platform for a technique not
  yet covered, open an issue or PR adding it to `docs/curriculum-map.md`.
- **Grading rubric / assessment improvements.**

## What we do not accept

- **Working vulnerable C programs** as reference implementations or
  "solutions," even for teaching purposes.
- **Working exploit code** (Python, pwntools scripts, shellcode,
  ROP chains) for any exercise, including as an "instructor answer
  key."
- **Bypass code for ASLR, DEP/NX, stack canaries, etc.** as ready-to-
  run scripts.

Pull requests containing the above will be closed, not merged. This
isn't a judgment on the contributor's intent — it's a fixed scope
boundary for this repository. If you've built vulnerable exercises or
exploit walkthroughs of your own, consider publishing them in your own
separate repository and linking to it from `docs/curriculum-map.md`
as an external resource instead.

## PR process

1. Open an issue first for anything beyond a small fix, so we can
   confirm scope before you put in the work.
2. Follow the module template structure exactly for new exercises.
3. Keep `template.c` free of any vulnerability-relevant logic — it
   should compile, run, and do nothing insecure on its own.
4. Include a clear objective statement and at least one external
   resource link in every module `README.md`.

## Code of conduct

Be respectful. This project exists to make binary exploitation
education more accessible, particularly for Spanish-speaking and
Puerto Rico / Latin America based learners who currently have limited
options in this space. Keep contributions aligned with that mission.
