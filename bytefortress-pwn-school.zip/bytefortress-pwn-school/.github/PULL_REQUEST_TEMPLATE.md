## Summary

## Checklist

- [ ] I have read `CONTRIBUTING.md`.
- [ ] This PR does **not** include a working vulnerable C reference
      implementation.
- [ ] This PR does **not** include working exploit code, shellcode,
      or ROP chains.
- [ ] If this adds a module, it follows the existing structure:
      `README.md` (objective + external resource link) + bare
      `template.c` + `validate.sh` (structural checks only).
- [ ] Links to external resources have been verified working.

## Related issue (if any)
