---
name: General issue
about: Report a problem, suggest a module, or propose a resource link
title: ""
labels: ""
assignees: ""
---

**Type of issue**
- [ ] Bug in a script (`tools/`)
- [ ] Broken/outdated external resource link
- [ ] New module proposal
- [ ] Documentation improvement
- [ ] Other

**Description**

**Which module (if applicable)**

**Proposed change**

> Reminder: this repository does not accept working vulnerable
> binaries or exploit code as reference implementations — see
> CONTRIBUTING.md before proposing a new module.
